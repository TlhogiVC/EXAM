package st10445158_prog6112_exam_question2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MovieTicketTest {

    private MovieTicket instance;

    @Before
    public void setUp() {
        instance = new MovieTicket();
    }

    @After
    public void tearDown() {
        instance = null;
    }

    /**
     * Test of CalculateTotalPrice method, of class MovieTicket.
     */
    @Test
public void testCalculateTotalPrice() {
    System.out.println("Testing CalculateTotalPrice...");

    // Test case 1: Valid data
    int numberOfTickets = 3;
    double ticketPrice = 50.0;
    double expResult = numberOfTickets * ticketPrice * 1.14; // Includes VAT (14%)
    double result = instance.CalculateTotalPrice(numberOfTickets, ticketPrice);
    assertEquals(expResult, result, 0.01); // Allows a delta of 0.01 for floating-point precision

    // Test case 2: Zero tickets
    numberOfTickets = 0;
    ticketPrice = 50.0;
    expResult = 0.0;
    result = instance.CalculateTotalPrice(numberOfTickets, ticketPrice);
    assertEquals(expResult, result, 0.01);

    // Test case 3: Zero ticket price
    numberOfTickets = 3;
    ticketPrice = 0.0;
    expResult = 0.0;
    result = instance.CalculateTotalPrice(numberOfTickets, ticketPrice);
    assertEquals(expResult, result, 0.01);

    // Test case 4: Negative ticket count
    numberOfTickets = -2;
    ticketPrice = 50.0;
    expResult = numberOfTickets * ticketPrice * 1.14;
    result = instance.CalculateTotalPrice(numberOfTickets, ticketPrice);
    assertEquals(expResult, result, 0.01);
}

    /**
     * Test of ValidateData method, of class MovieTicket.
     */
    @Test
    public void testValidateData() {
        System.out.println("Testing ValidateData...");

        // Test case 1: Valid data
        MovieTicketData validData = new MovieTicketData("Avatar", 3, 50, 150);
        boolean expResult = true;
        boolean result = instance.ValidateData(validData);
        assertEquals(expResult, result);

        // Test case 2: Invalid data (empty movie name)
        MovieTicketData invalidData1 = new MovieTicketData("", 3, 50, 150);
        expResult = false;
        result = instance.ValidateData(invalidData1);
        assertEquals(expResult, result);

        // Test case 3: Invalid data (negative tickets)
        MovieTicketData invalidData2 = new MovieTicketData("Avatar", -1, 50, 150);
        expResult = false;
        result = instance.ValidateData(invalidData2);
        assertEquals(expResult, result);

        // Test case 4: Invalid data (negative price)
        MovieTicketData invalidData3 = new MovieTicketData("Avatar", 3, -50, 150);
        expResult = false;
        result = instance.ValidateData(invalidData3);
        assertEquals(expResult, result);
    }
}
