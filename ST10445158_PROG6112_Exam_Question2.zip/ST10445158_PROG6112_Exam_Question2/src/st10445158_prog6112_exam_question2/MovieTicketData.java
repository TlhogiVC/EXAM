package st10445158_prog6112_exam_question2;

public class MovieTicketData
    {
        String Movie;
        int Tickets;
        int Price;
        int Total;

        public MovieTicketData(String Movie, int Tickets,int Price, int Total)
        {
            this.Movie=Movie;
            this.Tickets=Tickets;
            this.Price=Price;
            this.Total=Total;
        }
    }
        
        
        
        
        
        
