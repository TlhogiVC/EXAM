package st10445158_prog6112_exam_question2;

import javax.swing.JFrame;

public class ST10445158_PROG6112_Exam_Question2 
{

    public static void main(String[] args) 
    {
        MovieTickets MT = new MovieTickets();
        MT.setVisible(true);
        MT.setTitle("MOVIE TICKETS");
        MT.setSize(400, 400);
        MT.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
