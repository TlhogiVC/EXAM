package st10445158_prog6112_exam_question2;

public class MovieTicket implements iMovieTickets{

    @Override
    public double CalculateTotalPrice(int numberOfTickets, double ticketPrice) {
    return numberOfTickets * ticketPrice * 1.14; // Add 14% VAT
    }


    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) 
    {
    return movieTicketData.Movie != null && !movieTicketData.Movie.isEmpty()
           && movieTicketData.Price > 0
           && movieTicketData.Tickets > 0;
    }
    
}
