package st10445158_prog6112_exam_question2;

public interface iMovieTickets 
{
    double CalculateTotalPrice(int numberOfTickets, double ticketPrice);
    boolean ValidateData(MovieTicketData movieTicketData);
}
