package st10445158_prog6112_exam;

public interface iMovieTickets 
{
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}
