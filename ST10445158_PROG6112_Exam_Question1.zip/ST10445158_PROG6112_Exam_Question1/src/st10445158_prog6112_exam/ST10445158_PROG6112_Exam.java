package st10445158_prog6112_exam;

public class ST10445158_PROG6112_Exam {
    // Static variables to store movie information and monthly sales
    public static String Movie = "";
    public static int JAN = 0;
    public static int FEB = 0;
    public static int MAR = 0;
    public static int Total = 0;

    public static void main(String[] args) {
        // Instantiate the MovieTickets class to use its methods
        MovieTickets MT = new MovieTickets();

        // Array to store the names of the top movies
        String[] topMovies = {"Napoleon", "Oppenheimer"};

        // 2D array to store ticket sales for each movie in January, February, and March
        int[][] TotalMovieSales = {
            {3000, 1500, 1700}, // Sales for "Napoleon"
            {3500, 1200, 1600}  // Sales for "Oppenheimer"
        };

        // Display the header for the movie ticket sales report
        System.out.println("MOVIE TICKET SALES REPORT - 2024\n\t\t\tJAN\t\tFEB\t\tMAR");
        System.out.println("------------------------------------------------------");

        // Loop through the topMovies array to display each movie's sales data
        for (int i = 0; i < topMovies.length; i++) {
            // Assign sales data to variables for clarity
            Movie = topMovies[i];
            JAN = TotalMovieSales[i][0];
            FEB = TotalMovieSales[i][1];
            MAR = TotalMovieSales[i][2];

            // Print the sales data for the current movie
            System.out.println(Movie + "\t\t" + JAN + "\t\t" + FEB + "\t\t" + MAR);
        }

        System.out.println(); // Blank line for better readability

        // Array to store the total sales for each movie
        int[] totalSales = new int[topMovies.length];

        // Loop to calculate and display the total sales for each movie
        for (int i = 0; i < TotalMovieSales.length; i++) {
            // Calculate the total sales using the TotalMovieSales method
            totalSales[i] = MT.TotalMovieSales(TotalMovieSales[i]);

            // Print the total sales for the current movie
            System.out.println("Total movie ticket sales for " + topMovies[i] + " R" + totalSales[i]);
        }

        System.out.println(); // Blank line for better readability

        // Determine the top movie based on total sales
        String topMovie = MT.TopMovie(topMovies, totalSales);

        // Display the top movie
        System.out.println("Top performing movie: " + topMovie);
    }
}
