package st10445158_prog6112_exam;

public class MovieTickets implements iMovieTickets {

    // Override the TotalMovieSales method from the iMovieTickets interface
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0; // Initialize the total sales variable

        // Loop through each month's sales and calculate the total
        for (int sale : movieTicketSales) {
            total += sale; // Add each month's sales to the total
        }

        // Return the calculated total sales
        return total;
    }

    // Override the TopMovie method from the iMovieTickets interface
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxIndex = 0; // Initialize the index for the movie with the highest sales
        int maxSales = totalSales[0]; // Assume the first movie has the highest sales initially

        // Loop through the totalSales array to find the movie with the highest sales
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i]; // Update the maximum sales
                maxIndex = i;             // Update the index of the top movie
            }
        }

        // Return the name of the movie with the highest sales
        return movies[maxIndex];
    }
}
