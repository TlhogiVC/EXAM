
package st10445158_prog6112_exam;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tlhogi Kgatshe
 */
public class MovieTicketsTest {
    
    public MovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of TotalMovieSales method, of class MovieTickets.
     */
    private final MovieTickets movieTickets = new MovieTickets();

   @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Arrange
        int[] monthlySales = {3000, 1500, 1700};
        int expectedTotal = 6200; // 3000 + 1500 + 1700

        // Act
        int actualTotal = movieTickets.TotalMovieSales(monthlySales);

        // Assert
        assertEquals("The total sales calculation should match the expected total", expectedTotal, actualTotal);
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Arrange
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300}; // Oppenheimer has the highest sales
        String expectedTopMovie = "Oppenheimer";

        // Act
        String actualTopMovie = movieTickets.TopMovie(movies, totalSales);

        // Assert
        assertEquals("The method should return the movie with the highest sales", expectedTopMovie, actualTopMovie);
    }
}